package com.rest.lombok13.glcaRestLombokHealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlcaRestLombokHealthApplicationTests {

	@Test
	void contextLoads() {
	}

}
