package com.rest.lombok13.glcaRestLombokHealth.service;

import com.rest.lombok13.glcaRestLombokHealth.model.GreatLearning;

public interface ExampleService {

	public GreatLearning get();
	public GreatLearning  custominfo(String courseName,String courseType,String FirstName,String LastName);

	
}
