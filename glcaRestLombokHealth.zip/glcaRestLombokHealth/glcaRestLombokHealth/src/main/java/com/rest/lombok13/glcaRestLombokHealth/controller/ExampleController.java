package com.rest.lombok13.glcaRestLombokHealth.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.lombok13.glcaRestLombokHealth.model.GreatLearning;

//@Controller
@RestController("/")
public class ExampleController {

	
	//@ResponseBody
	@GetMapping("/info")
	public GreatLearning get()
	{
		GreatLearning greateLearning = new GreatLearning();
		greateLearning.setCourseName("Lear Controller in Spring Boot");
		greateLearning.setCourseType("Information Technology");
		greateLearning.setInstructorName("Christano Philliip");
		 return greateLearning;
	}
	
	@PostMapping("/customInfo")
	public GreatLearning  customInfo(String courseName,String courseType,String instructorName)
	{
		GreatLearning greateLearning = new GreatLearning();
		greateLearning.setCourseName(courseName);
		greateLearning.setCourseType(courseType);
		greateLearning.setInstructorName(instructorName);
		 return greateLearning;
		
	}
	
	
}
