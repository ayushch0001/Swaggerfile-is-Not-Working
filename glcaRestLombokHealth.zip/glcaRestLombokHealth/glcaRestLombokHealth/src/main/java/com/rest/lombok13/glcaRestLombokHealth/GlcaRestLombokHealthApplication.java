package com.rest.lombok13.glcaRestLombokHealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rest.lombok13.glcaRestLombokHealth.model.GreatLearning;

@SpringBootApplication(scanBasePackages= {"com.rest.lombok13.glcaRestLombokHealth","com.rest.lombok13.glcaRestLombokHealth.config","com.rest.lombok13.glcaRestLombokHealth.controller","com.rest.lombok13.glcaRestLombokHealth.model"})
public class GlcaRestLombokHealthApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlcaRestLombokHealthApplication.class, args);
		
		System.out.println("Hello spring boot");
		System.out.println("Hello Dev Tool");
	}
	

	public void run(String... args) throws Exception
	{
		GreatLearning greateLearning = new GreatLearning();
		greateLearning.setCourseName("Design Microveservice with Spring Boot");
		greateLearning.setCourseType("Information Technology");
		greateLearning.setInstructorName("Christiano Technology");
		
		System.out.println("Greaate learning "+greateLearning);
	}
}
