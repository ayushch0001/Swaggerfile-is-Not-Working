package com.rest.lombok13.glcaRestLombokHealth.model;

import lombok.Data;

//import lombok.Getter
//import lombok.Setter;
//import lombok.toString;

//@NoArgaConstructor
//@AllArgsConstructor
//@Builder
//@Getter                        ==@Data
//@Setter
//@ToString

@Data
public class GreatLearning {
	
	private String courseName;
	private String courseType;
	private String instructorName;
	

}
