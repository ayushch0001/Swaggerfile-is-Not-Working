package com.rest.lombok13.glcaRestLombokHealth.service;

import org.springframework.stereotype.Service;

import com.rest.lombok13.glcaRestLombokHealth.model.FullName;
import com.rest.lombok13.glcaRestLombokHealth.model.GreatLearning;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExampleServiceImpl implements ExampleService{@Override
	public GreatLearning get() {
		
	GreatLearning greatLearning = new GreatLearning();
	greatLearning.setCourseName("BackEnd Course");
	greatLearning.setCourseType("Information Technology");
	greatLearning.setInstructorName(FullName.builder().FirstName("K Akhil").LastName("Sai").build());
	
		return null;
	}

	@Override
	public GreatLearning custominfo(String courseName, String courseType, String FirstName, String LastName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
