package com.rest.lombok13.glcaRestLombokHealth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2WebMvc;


@Configuration
@EnableSwagger2WebMvc
public class SwaggerConfig { 

	@Bean
	public Docket libraryApi()
	{
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo())
				.groupName("Library-API").select()
				.apis(RequestHandlerSelectors
				 .basePackage("com.rest.lombok13.glcaRestLombokHealth.controller"))
				.build();
	}
	
	@Bean
	public ApiInfo apiInfo()
	{
		 return new ApiInfoBuilder().title("Library API")
				.description("Library API REFERENCE  for developers")
				.termsOfServiceUrl("http://fakeLibrary.com")
				.contact(new Contact("Library API","http://fakeLibrary.com","fakeLibarary@gamil.com"))
				.license("Library License")
				.licenseUrl("http://fakeLibrary.com")
				.version("1.0")
				.build();
	}
}
